echo > abc.txt
#awk -F, '{print $1,$2}' test_id.dat > s3.dat

while read -r s t
do
        echo -n "$t,$s," >> abc.txt
	curl "https://go.drugbank.com/structures/small_molecule_drugs/${s}.smiles" >> abc.txt

#https://go.drugbank.com/structures/small_molecule_drugs/DB03606.smiles

	echo "" >> abc.txt
done < drug_name.dat

